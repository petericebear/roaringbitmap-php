#!/usr/bin/env bash
set -eu

# A local development build only: no installation or php.ini changes.
root="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
build="$root/.build/croaring"
version="5.4.0"
mkdir -p "$build"
for file in roaring.c roaring.h; do
    curl -fsSL --max-time 120 "https://github.com/RoaringBitmap/CRoaring/releases/download/v$version/$file" -o "$build/$file"
done
php -r '
    $expected = [
        "roaring.c" => "cdbd007b635b9bb2dc2074c69cb9f768e8aaf2dbe68f622c8643689b4e975dbc",
        "roaring.h" => "b74054da2965baa17393c5ffa02bea587374fe33afcfff2c2d24dcf75fed419b",
    ];
    foreach ($expected as $file => $hash) {
        if (hash_file("sha256", $argv[1] . "/" . $file) !== $hash) {
            fwrite(STDERR, "Checksum mismatch: " . $file . PHP_EOL);
            exit(1);
        }
    }
' "$build"
curl -fsSL --max-time 30 "https://raw.githubusercontent.com/RoaringBitmap/CRoaring/v$version/LICENSE" -o "$build/LICENSE"
case "$(uname -s)" in
    Darwin) suffix=dylib; shared=-dynamiclib ;;
    Linux) suffix=so; shared=-shared ;;
    *) echo "This helper supports Linux and macOS. Build CRoaring separately on Windows." >&2; exit 1 ;;
esac
"${CC:-cc}" -O3 -std=c11 "$shared" -fPIC "$build/roaring.c" -o "$build/libroaring.$suffix"
printf 'Built %s\n' "$build/libroaring.$suffix"
